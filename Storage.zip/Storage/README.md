# Storage

## Specification

The contract Storage allows a user to 
store insiede the blockchain two 
typologies of dynamic size data: 
a byte sequence and a string.

After contract creation, the contract 
allows two actions:
- **storeBytes**, which allows the user
to store an arbitrary 
sequence of bytes;
- **storeString**, which allows the user 
to store a string of arbitrary 
length.

## Execution traces
// SPDX-License-Identifier: GPL-3.0

pragma solidity ^0.8.0;

contract DataStorage {

    bytes public byteSequence;
    string public textString;

    function storeBytes(bytes memory _byteSequence) public {
        byteSequence =  _byteSequence;
    }

    function storeString(string memory  _textString) public {
        textString = _textString;
    }

}