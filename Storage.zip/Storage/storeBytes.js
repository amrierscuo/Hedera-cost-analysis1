const {
  Client,
  PrivateKey,
  ContractExecuteTransaction,
  ContractFunctionParameters,
  ContractId,
  Hbar,
} = require("@hashgraph/sdk");

require("dotenv").config();

const myAccountId = process.env.MY_ACCOUNT_ID;
const myPrivateKey = PrivateKey.fromString(process.env.MY_PRIVATE_KEY);

const client = Client.forTestnet();
client.setOperator(myAccountId, myPrivateKey);

client.setMaxQueryPayment(new Hbar(50));

async function storeBytes() {
  const contractId = ContractId.fromString("0.0.14991538"); // ID

  //const data = Buffer.from("Hello, world!");
  const data = Buffer.from([0x48, 0x65, 0x6c, 0x6c, 0x6f]);  // Bytes for "Hello" in ASCII

  const contractExecTx = new ContractExecuteTransaction()
    .setContractId(contractId)
    .setGas(1000000)
    .setFunction("storeBytes", new ContractFunctionParameters().addBytes(data));

  const submitExecTx = await contractExecTx.execute(client);
  const receipt = await submitExecTx.getReceipt(client);

  console.log("Status of storeBytes function call: " + receipt.status.toString());
}

storeBytes().catch(console.error);
