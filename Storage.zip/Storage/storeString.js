const {
  Client,
  PrivateKey,
  ContractCallQuery,
  Hbar,
  ContractExecuteTransaction,
  ContractFunctionParameters,
  ContractId,
} = require("@hashgraph/sdk");

require("dotenv").config();

const myAccountId = process.env.MY_ACCOUNT_ID;
const myPrivateKey = PrivateKey.fromString(process.env.MY_PRIVATE_KEY);

const client = Client.forTestnet();
client.setOperator(myAccountId, myPrivateKey);

client.setMaxQueryPayment(new Hbar(50));

async function storeString() {
  const contractId = ContractId.fromString("0.0.14991538"); // ID

  const contractExecTx = new ContractExecuteTransaction()
    .setContractId(contractId)
    .setGas(1000000)
    .setFunction("storeString", new ContractFunctionParameters().addString("Hello, world!"));

  const submitExecTx = await contractExecTx.execute(client);
  const receipt = await submitExecTx.getReceipt(client);

  console.log("Status of storeString function call: " + receipt.status.toString());
}

storeString().catch(console.error);
