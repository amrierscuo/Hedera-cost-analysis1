require("dotenv").config();
const {
  Client,
  PrivateKey,
  FileCreateTransaction,
  ContractCreateTransaction,
  ContractFunctionParameters,
  ContractExecuteTransaction,
  Hbar,
  AccountBalanceQuery,
} = require("@hashgraph/sdk");
const { keccak256 } = require('js-sha3');

const operatorPrivateKey = PrivateKey.fromString(
  process.env.MY_PRIVATE_KEY
);
const operatorId = process.env.MY_ACCOUNT_ID;

let client = Client.forTestnet();
client.setOperator(operatorId, operatorPrivateKey);
client.setDefaultMaxTransactionFee(new Hbar(100));
client.setMaxQueryPayment(new Hbar(50));

let dataStorage = require("./HTLC.json");
const bytecode = dataStorage.data.bytecode.object;

async function storeBytecode() {
  const fileCreateTx = new FileCreateTransaction().setContents(bytecode);
  const submitTx = await fileCreateTx.execute(client);
  const fileReceipt = await submitTx.getReceipt(client);
  const bytecodeFileId = fileReceipt.fileId;
  console.log("The smart contract bytecode file ID is " + bytecodeFileId);
  
  return bytecodeFileId;
}

async function checkAccountBalance(accountId) {
  const balanceQuery = new AccountBalanceQuery().setAccountId(accountId);
  const balance = await balanceQuery.execute(client);

  console.log("The balance of account " + accountId + " is: " + balance.hbars.toString());
}

async function deployContract(bytecodeFileId, verifier, hash, delay, collateralHBAR) {
  // Check account balance before deployment
  console.log("Checking account balance before deployment...");
  await checkAccountBalance("0.0.4652957").catch(console.error);
  await checkAccountBalance("0.0.10610753").catch(console.error);
  await checkAccountBalance("0.0.10611009").catch(console.error);

  const contractTx = new ContractCreateTransaction()
    .setBytecodeFileId(bytecodeFileId)
    .setGas(400000)
    .setConstructorParameters(
      new ContractFunctionParameters()
        .addString(verifier)
        .addBytes(hash)
        .addUint256(delay)
        .addUint256(collateralHBAR)
    )
    .setInitialBalance(new Hbar(collateralHBAR))
    .setAutoRenewPeriod(7890000);

  const response = await contractTx.execute(client);
  const receipt = await response.getReceipt(client);
  const contractId = receipt.contractId;

  return contractId;
}

async function reveal(contractId, secret) {
  const revealTx = new ContractExecuteTransaction()
    .setContractId(contractId)
    .setGas(400000)
    .setFunction("reveal", new ContractFunctionParameters().addString(secret));

  const transactionResponse = await revealTx.execute(client);
  console.log(transactionResponse);
  const receipt = await transactionResponse.getReceipt(client);
  return receipt;
}

async function timeout(contractId) {
  const timeoutTx = new ContractExecuteTransaction()
    .setContractId(contractId)
    .setGas(400000)
    .setFunction("timeout");

  const transactionResponse = await timeoutTx.execute(client);
  console.log(transactionResponse);
  const receipt = await transactionResponse.getReceipt(client);
  return receipt;
}

async function execute() {
  console.log("Checking account balances before execute...");
  await checkAccountBalance("0.0.4652957").catch(console.error);
  await checkAccountBalance("0.0.10610753").catch(console.error);
  await checkAccountBalance("0.0.10611009").catch(console.error);

  console.log("Storing the contract bytecode...");
  const bytecodeFileId = await storeBytecode();
  console.log("Bytecode stored successfully.");

  const delay = Math.floor(Date.now() / 1000) + 100;
  const verifier = process.env.MY_ACCOUNT_ID2;
  const secret = "MySecret";
  const hash = Buffer.from(keccak256(secret), 'hex');
  const collateralHBAR = 1; // Importo del collaterale in HBAR

  console.log("Deploying new contract...");
  const contractId = await deployContract(bytecodeFileId, verifier, hash, delay, collateralHBAR);
  console.log("Deployed new contract with ID:", contractId.toString());

  // Wait a bit before revealing
  console.log("Waiting 4 seconds before reveal...");
  await new Promise(r => setTimeout(r, 4000));

  console.log("Revealing secret...");
  console.log("Sender address: ", client.operatorAccountId.toString());
  console.log("Expected hash: ", hash.toString('hex'));
  console.log("Hash of revealed secret: ", Buffer.from(keccak256(secret), 'hex').toString('hex'));

  const revealReceipt = await reveal(contractId, secret);
  console.log("Secret revealed. Status:", revealReceipt.status.toString());

  // Wait for the deadline to pass before calling timeout
  console.log("Waiting for deadline to pass before calling timeout...");
  await new Promise(r => setTimeout(r, 105000));

  console.log("Calling timeout...");
  const timeoutReceipt = await timeout(contractId);
  console.log("Timeout called. Status:", timeoutReceipt.status.toString());
}

execute().catch(console.error);
